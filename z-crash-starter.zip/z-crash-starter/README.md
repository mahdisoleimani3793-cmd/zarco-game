# Z-CRASH (virtual-credit demo)

A responsive Persian/RTL crash-style game demo built with Next.js and React. It uses **virtual points only**. No deposits, cash-outs, cryptocurrency, real-money wagering, or conversion of points to money are implemented.

## Requirements
- Node.js 18.17+ (Node 20 LTS recommended)
- npm

## Run locally
```bash
npm install
npm run dev
```
Open http://localhost:3000

## Production build
```bash
npm run build
npm start
```

## Important limitations
- The round logic is client-side and is not secure or authoritative.
- Balances and history reset on refresh.
- This is a front-end prototype, not a production-ready multiplayer service.
- Before public deployment, review applicable laws, privacy obligations, advertising policies, accessibility, and security.
- If adding accounts, store credentials safely and enforce all balance/game logic on a server. Do not add real-money wagering or cash-equivalent rewards without qualified legal review and appropriate authorization.
